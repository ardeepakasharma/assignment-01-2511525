-- 3NF Schema Design

-- Create Customers table
CREATE TABLE Customers (
    customer_id VARCHAR(10) PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    customer_email VARCHAR(100) NOT NULL,
    customer_city VARCHAR(50) NOT NULL
);

-- Create Products table
CREATE TABLE Products (
    product_id VARCHAR(10) PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL
);

-- Create SalesRepresentatives table
CREATE TABLE SalesRepresentatives (
    sales_rep_id VARCHAR(10) PRIMARY KEY,
    sales_rep_name VARCHAR(100) NOT NULL,
    sales_rep_email VARCHAR(100) NOT NULL,
    office_address VARCHAR(255) NOT NULL
);

-- Create Orders table
CREATE TABLE Orders (
    order_id VARCHAR(10) PRIMARY KEY,
    customer_id VARCHAR(10) NOT NULL,
    sales_rep_id VARCHAR(10) NOT NULL,
    order_date DATE NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
    FOREIGN KEY (sales_rep_id) REFERENCES SalesRepresentatives(sales_rep_id)
);

-- Create OrderItems table (to link orders and products)
CREATE TABLE OrderItems (
    order_id VARCHAR(10),
    product_id VARCHAR(10),
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    PRIMARY KEY (order_id, product_id),
    FOREIGN KEY (order_id) REFERENCES Orders(order_id),
    FOREIGN KEY (product_id) REFERENCES Products(product_id)
);

-- Populate Data

-- Customers
INSERT INTO Customers (customer_id, customer_name, customer_email, customer_city) VALUES ('C002', 'Priya Sharma', 'priya@gmail.com', 'Delhi');
INSERT INTO Customers (customer_id, customer_name, customer_email, customer_city) VALUES ('C001', 'Rohan Mehta', 'rohan@gmail.com', 'Mumbai');
INSERT INTO Customers (customer_id, customer_name, customer_email, customer_city) VALUES ('C006', 'Neha Gupta', 'neha@gmail.com', 'Delhi');
INSERT INTO Customers (customer_id, customer_name, customer_email, customer_city) VALUES ('C003', 'Amit Verma', 'amit@gmail.com', 'Bangalore');
INSERT INTO Customers (customer_id, customer_name, customer_email, customer_city) VALUES ('C005', 'Vikram Singh', 'vikram@gmail.com', 'Mumbai');

-- Products
INSERT INTO Products (product_id, product_name, category, unit_price) VALUES ('P004', 'Notebook', 'Stationery', 120);
INSERT INTO Products (product_id, product_name, category, unit_price) VALUES ('P007', 'Pen Set', 'Stationery', 250);
INSERT INTO Products (product_id, product_name, category, unit_price) VALUES ('P005', 'Headphones', 'Electronics', 3200);
INSERT INTO Products (product_id, product_name, category, unit_price) VALUES ('P003', 'Desk Chair', 'Furniture', 8500);
INSERT INTO Products (product_id, product_name, category, unit_price) VALUES ('P006', 'Standing Desk', 'Furniture', 22000);

-- SalesRepresentatives
INSERT INTO SalesRepresentatives (sales_rep_id, sales_rep_name, sales_rep_email, office_address) VALUES ('SR02', 'Anita Desai', 'anita@corp.com', 'Delhi Office, Connaught Place, New Delhi - 110001');
INSERT INTO SalesRepresentatives (sales_rep_id, sales_rep_name, sales_rep_email, office_address) VALUES ('SR01', 'Deepak Joshi', 'deepak@corp.com', 'Mumbai HQ, Nariman Point, Mumbai - 400021');
INSERT INTO SalesRepresentatives (sales_rep_id, sales_rep_name, sales_rep_email, office_address) VALUES ('SR03', 'Ravi Kumar', 'ravi@corp.com', 'South Zone, MG Road, Bangalore - 560001');

-- Orders
INSERT INTO Orders (order_id, customer_id, sales_rep_id, order_date) VALUES ('ORD1027', 'C002', 'SR02', '2023-11-02');
INSERT INTO Orders (order_id, customer_id, sales_rep_id, order_date) VALUES ('ORD1114', 'C001', 'SR01', '2023-08-06');
INSERT INTO Orders (order_id, customer_id, sales_rep_id, order_date) VALUES ('ORD1153', 'C006', 'SR01', '2023-02-14');
INSERT INTO Orders (order_id, customer_id, sales_rep_id, order_date) VALUES ('ORD1002', 'C002', 'SR02', '2023-01-17');
INSERT INTO Orders (order_id, customer_id, sales_rep_id, order_date) VALUES ('ORD1118', 'C006', 'SR02', '2023-11-10');

-- OrderItems
INSERT INTO OrderItems (order_id, product_id, quantity) VALUES ('ORD1027', 'P004', 4);
INSERT INTO OrderItems (order_id, product_id, quantity) VALUES ('ORD1114', 'P007', 2);
INSERT INTO OrderItems (order_id, product_id, quantity) VALUES ('ORD1153', 'P007', 3);
INSERT INTO OrderItems (order_id, product_id, quantity) VALUES ('ORD1002', 'P005', 1);
INSERT INTO OrderItems (order_id, product_id, quantity) VALUES ('ORD1118', 'P007', 5);