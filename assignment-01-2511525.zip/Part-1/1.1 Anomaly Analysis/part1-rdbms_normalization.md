## Anomaly Analysis

# Insert Anomaly
An *Insert Anomaly* occurs when certain data cannot be added to the database without the presence of other data. In `orders_flat.csv`, it is impossible to add a new **Product** to the system (e.g., `product_id: P009`, `product_name: Keyboard`) without an accompanying order.

* *Citation:* To record a new product, one would be forced to create a dummy record with an `order_id` (e.g., `ORD0000`) and a `customer_id`, because the table structure is centered around the order transaction.

# Update Anomaly
An *Update Anomaly* occurs when data is duplicated, and updating it in one place but not others leads to inconsistency. 

* *Citation:* Sales Representative *SR01 (Deepak Joshi)* has inconsistent `office_address` values. In **Row 1** (order `ORD1114`), the address is `"Mumbai HQ, Nariman Point, Mumbai - 400021"`, whereas in **Row 37** (order `ORD1180`), it is recorded as `"Mumbai HQ, Nariman Pt, Mumbai - 400021"`. This inconsistency demonstrates that updating a sales rep's information requires changing every row where they appear, which is prone to error.

# Delete Anomaly
A *Delete Anomaly* occurs when deleting a record results in the unintended loss of other related data. 

* *Citation:* If the company deletes the order records for **Customer C001 (Rohan Mehta)** (e.g., **Row 1**, **Row 11**, etc.), all information about that customer—including their email (`rohan@gmail.com`) and city (`Mumbai`)—is permanently removed from the database, as there is no separate table to store customer details independently of orders.
