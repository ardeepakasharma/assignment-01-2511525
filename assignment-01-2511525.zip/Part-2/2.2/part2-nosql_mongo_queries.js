// OP1: insertMany() — insert all 3 documents from sample_documents.json
db.products.insertMany([
  {
    "product_id": "E1001",
    "name": "Ultra-Wide Gaming Monitor",
    "category": "Electronics",
    "brand": "ViewSonic",
    "price": 9999.99,
    "specifications": {
      "screen_size": "34 inch",
      "resolution": "3440 x 1440",
      "refresh_rate": "144Hz",
      "voltage": "110-240V",
      "ports": [
        "HDMI 2.0",
        "DisplayPort 1.4",
        "USB-C"
      ]
    },
    "warranty": {
      "period": "3 years",
      "type": "Manufacturer Limited Warranty",
      "coverage": [
        "Parts",
        "Labor"
      ]
    },
    "stock_quantity": 45
  },
  {
    "product_id": "C2005",
    "name": "Premium Cotton Crewneck T-Shirt",
    "category": "Clothing",
    "brand": "Urban Threads",
    "price": 1500,
    "attributes": {
      "material": "100% Organic Cotton",
      "colors": [
        "Midnight Blue",
        "Heather Grey",
        "Classic White"
      ],
      "sizes": [
        "S",
        "M",
        "L",
        "XL",
        "XXL"
      ],
      "care_instructions": "Machine wash cold, tumble dry low"
    },
    "fit": "Regular Fit",
    "collection": "Essentials 2024"
  },
  {
    "product_id": "G3009",
    "name": "Organic Almond Milk",
    "category": "Groceries",
    "brand": "Nature's Best",
    "price": 50,
    "expiry_date": "2024-12-15",
    "nutritional_info": {
      "serving_size": "240ml",
      "calories": 30,
      "total_fat": "2.5g",
      "sugar": "0g",
      "vitamins": [
        "Vitamin E",
        "Vitamin D2",
        "Calcium"
      ]
    },
    "storage_instructions": "Refrigerate after opening",
    "dietary_labels": [
      "Vegan",
      "Gluten-Free",
      "Non-GMO"
    ]
  }
]);

// OP2: find() — retrieve all Electronics products with price > 20000
db.products.find({
    category: "Electronics",
    price: { $gt: 20000 }
});

// OP3: find() — retrieve all Groceries expiring before 2025-01-01
db.products.find({
    category: "Groceries",
    expiry_date: { $lt: "2025-01-01" }
});

// OP4: updateOne() — add a "discount_percent" field to a specific product
db.products.updateOne(
    { product_id: "E1001" },
    { $set: { discount_percent: 15 } }
);

// OP5: createIndex() — create an index on category field and explain why
db.products.createIndex({ category: 1 });
// Rationale: Creating an index on the 'category' field significantly improves query performance
// for lookups and aggregations filtered by category. Without an index, MongoDB must perform 
// a collection scan (checking every document), which is inefficient as the catalog grows.
