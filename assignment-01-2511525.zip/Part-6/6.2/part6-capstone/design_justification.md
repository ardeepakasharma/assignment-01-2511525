# Part 6: Design Justification

## Storage Systems
To meet the hospital's diverse goals, I have implemented a Polyglot Persistence strategy, selecting storage systems optimized for specific data velocities and structures:

* **Goal 1 (Readmission Risk):** I utilized a **Data Lake (e.g., S3/ADLS)**. Predicting risk requires high-volume historical treatment data. The Data Lake allows for the storage of massive datasets at a low cost, providing the "Silver" layer necessary for training ML models.
* **Goal 2 (Plain English Queries):** I selected a **Relational Data Warehouse** alongside a **Vector Database**. The Vector DB stores embeddings of clinical notes for semantic search, while the Data Warehouse provides the "Source of Truth" for structured history.
* **Goal 3 (Management Reports):** A **Cloud Data Warehouse (OLAP)** is used here. For department-wise costs and occupancy, data must be highly aggregated. This system is optimized for complex JOIN operations.
* **Goal 4 (ICU Vitals):** I chose a **Time-Series Database (e.g., InfluxDB)**. ICU vitals are high-frequency, sequential data points. A time-series DB excels at rapid writes and "windowed" queries (e.g., 5-minute averages).

## OLTP vs OLAP Boundary
The boundary in this design is defined by the **Extraction, Transformation, and Loading (ETL) process**. The **OLTP (Online Transactional Processing)** side consists of the live EHR and Bed Management databases, optimized for row-level consistency and instant updates. These are never queried directly by the AI to avoid slowing down hospital operations.

The **OLAP (Online Analytical Processing)** side begins once data passes through the Ingestion Layer into the Data Lake and Warehouse. Here, the data is decoupled from production, transformed from normalized tables into de-normalized schemas, and optimized for high-speed analytical reads for AI and reporting.

## Trade-offs
A significant trade-off in this design is **Consistency vs. Latency** regarding ICU streaming data. By using a "Lambda" architecture—where vitals are processed in a real-time stream for alerts but stored in a Data Lake for long-term AI training—there is a risk of **Data Drift**. The real-time view might slightly differ from the "official" record due to network jitter.

**Mitigation:** I would implement a daily **reconciliation layer**. Every 24 hours, the system compares the streamed "speed layer" data against the raw logs from the ICU devices, overwriting any discrepancies in the Data Lake to ensure AI models are trained on validated, accurate history.