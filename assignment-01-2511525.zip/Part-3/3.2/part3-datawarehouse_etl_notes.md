## ETL Decisions

### Decision 1 — Temporal Standardization
**Problem:** The raw `date` field was a mess of multiple formats, including `DD/MM/YYYY`, `YYYY-MM-DD`, and `DD-MM-YYYY`. This would cause standard SQL sorting and filtering to fail.
**Resolution:** During the ETL process, I implemented a robust parsing logic that tried multiple format patterns. Successfully parsed dates were then converted into a smart surrogate key integer (`YYYYMMDD`). This ensures efficient indexing and allows for easy joining with the `dim_date` table.

### Decision 2 — Categorical Unification
**Problem:** The `category` field contained duplicate entries due to inconsistent casing and naming conventions (e.g., 'electronics', 'Electronics', 'Grocery', and 'Groceries').
**Resolution:** I applied a "Title Case" transformation to all category strings and standardized plurals. For instance, both "Grocery" and "Groceries" were unified into a single "Groceries" bucket. This was critical for **Q1** (Total sales revenue by category) to ensure revenue wasn't fragmented across synonymous labels.

### Decision 3 — Missing Data Imputation for Store City
**Problem:** The `store_city` column contained several `NULL` or missing values. Without a city, regional sales analysis and reporting become inaccurate.
**Resolution:** I cross-referenced `store_name` with known city locations from other valid rows. For example, if "Mumbai Central" had a null city, I mapped it back to "Mumbai." For any remaining unknowns that couldn't be inferred, I assigned a "Unknown" placeholder value to ensure the rows could still be loaded into the warehouse without violating NOT NULL constraints while flagging them for data quality review.
