-- Star Schema Design for Retail Analytics

-- 1. Dimension: dim_date
CREATE TABLE dim_date (
    date_key INT PRIMARY KEY,
    full_date DATE NOT NULL,
    day INT NOT NULL,
    month INT NOT NULL,
    year INT NOT NULL,
    quarter INT NOT NULL
);

-- 2. Dimension: dim_store
CREATE TABLE dim_store (
    store_key SERIAL PRIMARY KEY,
    store_name VARCHAR(100) NOT NULL,
    store_city VARCHAR(100)
);

-- 3. Dimension: dim_product
CREATE TABLE dim_product (
    product_key SERIAL PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL
);

-- 4. Fact Table: fact_sales
CREATE TABLE fact_sales (
    transaction_id VARCHAR(20) PRIMARY KEY,
    date_key INT NOT NULL,
    store_key INT NOT NULL,
    product_key INT NOT NULL,
    units_sold INT NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    total_amount DECIMAL(15, 2) NOT NULL,
    FOREIGN KEY (date_key) REFERENCES dim_date(date_key),
    FOREIGN KEY (store_key) REFERENCES dim_store(store_key),
    FOREIGN KEY (product_key) REFERENCES dim_product(product_key)
);

-- INSERT Sample Data (Cleaned and Standardized)

-- dim_date
INSERT INTO dim_date (date_key, full_date, day, month, year, quarter) VALUES (20230102, '2023-01-02', 2, 1, 2023, 1);
INSERT INTO dim_date (date_key, full_date, day, month, year, quarter) VALUES (20230120, '2023-01-20', 20, 1, 2023, 1);
INSERT INTO dim_date (date_key, full_date, day, month, year, quarter) VALUES (20230127, '2023-01-27', 27, 1, 2023, 1);
INSERT INTO dim_date (date_key, full_date, day, month, year, quarter) VALUES (20230204, '2023-02-04', 4, 2, 2023, 1);
INSERT INTO dim_date (date_key, full_date, day, month, year, quarter) VALUES (20230320, '2023-03-20', 20, 3, 2023, 1);
INSERT INTO dim_date (date_key, full_date, day, month, year, quarter) VALUES (20230401, '2023-04-01', 1, 4, 2023, 2);
INSERT INTO dim_date (date_key, full_date, day, month, year, quarter) VALUES (20230504, '2023-05-04', 4, 5, 2023, 2);
INSERT INTO dim_date (date_key, full_date, day, month, year, quarter) VALUES (20230829, '2023-08-29', 29, 8, 2023, 3);
INSERT INTO dim_date (date_key, full_date, day, month, year, quarter) VALUES (20230908, '2023-09-08', 8, 9, 2023, 3);

-- dim_store
INSERT INTO dim_store (store_key, store_name, store_city) VALUES (1, 'Chennai Anna', 'Chennai');
INSERT INTO dim_store (store_key, store_name, store_city) VALUES (2, 'Delhi South', 'Delhi');
INSERT INTO dim_store (store_key, store_name, store_city) VALUES (3, 'Bangalore MG', 'Bangalore');

-- dim_product
INSERT INTO dim_product (product_key, product_name, category) VALUES (1, 'Speaker', 'Electronics');

-- fact_sales
INSERT INTO fact_sales (transaction_id, date_key, store_key, product_key, units_sold, unit_price, total_amount) VALUES ('TXN5000', 20230829, 1, 1, 3, 49262.78, 147788.34);
INSERT INTO fact_sales (transaction_id, date_key, store_key, product_key, units_sold, unit_price, total_amount) VALUES ('TXN5258', 20230504, 1, 1, 10, 49262.78, 492627.8);
INSERT INTO fact_sales (transaction_id, date_key, store_key, product_key, units_sold, unit_price, total_amount) VALUES ('TXN5068', 20230401, 2, 1, 3, 49262.78, 147788.34);
INSERT INTO fact_sales (transaction_id, date_key, store_key, product_key, units_sold, unit_price, total_amount) VALUES ('TXN5090', 20230127, 2, 1, 9, 49262.78, 443365.02);
INSERT INTO fact_sales (transaction_id, date_key, store_key, product_key, units_sold, unit_price, total_amount) VALUES ('TXN5186', 20230320, 2, 1, 16, 49262.78, 788204.48);
INSERT INTO fact_sales (transaction_id, date_key, store_key, product_key, units_sold, unit_price, total_amount) VALUES ('TXN5222', 20230908, 2, 1, 18, 49262.78, 886730.04);
INSERT INTO fact_sales (transaction_id, date_key, store_key, product_key, units_sold, unit_price, total_amount) VALUES ('TXN5031', 20230102, 3, 1, 20, 49262.78, 985255.6);
INSERT INTO fact_sales (transaction_id, date_key, store_key, product_key, units_sold, unit_price, total_amount) VALUES ('TXN5043', 20230204, 3, 1, 16, 49262.78, 788204.48);
INSERT INTO fact_sales (transaction_id, date_key, store_key, product_key, units_sold, unit_price, total_amount) VALUES ('TXN5070', 20230204, 3, 1, 15, 49262.78, 738941.7);
INSERT INTO fact_sales (transaction_id, date_key, store_key, product_key, units_sold, unit_price, total_amount) VALUES ('TXN5095', 20230120, 3, 1, 5, 49262.78, 246313.9);
